-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 03 2013 г., 11:53
-- Версия сервера: 5.5.28
-- Версия PHP: 5.3.10-1ubuntu3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `sp684190_test45`
--

-- --------------------------------------------------------

--
-- Структура таблицы `avtor05`
--

DROP TABLE IF EXISTS `avtor05`;
CREATE TABLE IF NOT EXISTS `avtor05` (
  `name` varchar(80) CHARACTER SET cp1251 NOT NULL,
  `id` int(11) NOT NULL,
  `alf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `avtor05`
--

INSERT INTO `avtor05` (`name`, `id`, `alf`) VALUES
('Архипов', 1000001, 224),
('Айвазовский', 1000002, 224),
('Блонская', 1000003, 225),
('Богатов', 1000004, 225),
('Богданов', 1000005, 225),
('Бубликов', 1000006, 225),
('Бялыницкий-Бируля', 1000007, 225);

-- --------------------------------------------------------

--
-- Структура таблицы `cartina05`
--

DROP TABLE IF EXISTS `cartina05`;
CREATE TABLE IF NOT EXISTS `cartina05` (
  `name` varchar(80) CHARACTER SET cp1251 NOT NULL,
  `id` int(11) NOT NULL,
  `xol` varchar(80) CHARACTER SET cp1251 NOT NULL,
  `xyd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `cartina05`
--

INSERT INTO `cartina05` (`name`, `id`, `xol`, `xyd`) VALUES
('Ратник', 124, 'масло', 1000001),
('На мельнице', 33, 'масло', 1000001),
('Обратный', 237, 'масло', 1000001),
('Закат на море', 213, 'масло', 1000002),
('Лунная ночь', 57, 'масло', 1000002),
('Купальня в Феодосии', 337, 'масло', 1000002),
('Портрет мальчика Коли', 633, 'масло', 1000003),
('Портрет учительницы Ростовцевой', 629, 'масло', 1000003);

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL,
  `treg` int(11) NOT NULL,
  `txt` text CHARACTER SET cp1251 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `treg`, `txt`) VALUES
(750677, 1377677236, '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `log` varchar(50) NOT NULL,
  `pas` varchar(30) NOT NULL,
  `par1` varchar(60) NOT NULL,
  `par2` varchar(60) NOT NULL,
  `par3` varchar(60) NOT NULL,
  `par4` varchar(90) NOT NULL,
  `par5` varchar(15) NOT NULL,
  `par6` text NOT NULL,
  `par7` varchar(12) NOT NULL,
  `treg` int(11) NOT NULL,
  `adm` int(11) NOT NULL,
  `act` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`log`, `pas`, `par1`, `par2`, `par3`, `par4`, `par5`, `par6`, `par7`, `treg`, `adm`, `act`) VALUES
('wirtbox@mail.ru', 'next2008', '?????-?????', '', '', '', '', '', '', 1377591692, 1, 1),
('to363999@mail.ru', '331210', '?????', '', '', '', '', '', '', 1377591692, 1, 1),
('sp684190@mail.ru', 'lbhtrnjh15', '?????', '', '', '', '', '', '', 1377591692, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
